from django.apps import AppConfig


class UchihaConfig(AppConfig):
    name = 'uchiha'
