from django.contrib import admin
from .models import Notes4

admin.site.register(Notes4)